"""Douyin auto sender application."""
